<?php

use App\Models\Evento;
use App\Models\Pergunta;
use App\Models\User;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

function cenarioUpvote(): array
{
    $dono   = User::factory()->create();
    $evento = Evento::create(['titulo' => 'Evento Upvote', 'user_id' => $dono->id]);
    $pergunta = Pergunta::create([
        'evento_id' => $evento->id,
        'texto'     => 'Pergunta para votar nos testes',
        'status'    => 'pendente',
    ]);

    return [User::factory()->create(), $evento, $pergunta];
}

it('a tabela pivot existe e impede voto duplicado (unique composta)', function () {
    [$user, , $pergunta] = cenarioUpvote();

    expect(Schema::hasTable('pergunta_user'))->toBeTrue();

    DB::table('pergunta_user')->insert(['pergunta_id' => $pergunta->id, 'user_id' => $user->id]);

    expect(fn () => DB::table('pergunta_user')->insert(['pergunta_id' => $pergunta->id, 'user_id' => $user->id]))
        ->toThrow(QueryException::class);
});

it('Pergunta::votos() e User::perguntasVotadas() retornam BelongsToMany', function () {
    expect((new Pergunta())->votos())->toBeInstanceOf(BelongsToMany::class);
    expect((new User())->perguntasVotadas())->toBeInstanceOf(BelongsToMany::class);
});

it('visitante é redirecionado para o login e nenhum voto é gravado', function () {
    [, , $pergunta] = cenarioUpvote();

    $this->post(route('perguntas.votar', $pergunta))->assertRedirect(route('login'));

    $this->assertDatabaseCount('pergunta_user', 0);
});

it('votar insere o registro na pivot quando o usuário ainda não votou', function () {
    [$user, , $pergunta] = cenarioUpvote();

    $this->actingAs($user)->from('/')->post(route('perguntas.votar', $pergunta))->assertRedirect('/');

    $this->assertDatabaseHas('pergunta_user', ['pergunta_id' => $pergunta->id, 'user_id' => $user->id]);
});

it('votar de novo remove o registro (toggle)', function () {
    [$user, , $pergunta] = cenarioUpvote();

    $this->actingAs($user)->post(route('perguntas.votar', $pergunta));
    $this->actingAs($user)->post(route('perguntas.votar', $pergunta));

    $this->assertDatabaseMissing('pergunta_user', ['pergunta_id' => $pergunta->id, 'user_id' => $user->id]);
});

it('as perguntas do evento vêm ordenadas por votos_count decrescente', function () {
    [$user, $evento, $zero] = cenarioUpvote();
    $dois = Pergunta::create(['evento_id' => $evento->id, 'texto' => 'Pergunta com dois votos', 'status' => 'pendente']);
    $tres = Pergunta::create(['evento_id' => $evento->id, 'texto' => 'Pergunta com tres votos', 'status' => 'pendente']);

    $votantes = User::factory()->count(3)->create();
    $tres->votos()->attach($votantes->pluck('id'));
    $dois->votos()->attach($votantes->take(2)->pluck('id'));

    $response = $this->get(route('eventos.show', $evento->id))->assertOk();
    $perguntas = $response->viewData('perguntas');

    expect($perguntas->pluck('id')->all())->toBe([$tres->id, $dois->id, $zero->id]);
    expect($perguntas->first()->votos_count)->toBe(3);
});

it('a tela mostra a contagem e destaca o botão de quem já votou', function () {
    [$user, $evento, $pergunta] = cenarioUpvote();
    $url = route('eventos.show', $evento->id);

    $this->actingAs($user)->get($url)->assertOk()->assertSee('Upvote')->assertDontSee('Votado (remover)');

    $pergunta->votos()->attach($user->id);

    $this->actingAs($user)->get($url)->assertOk()->assertSee('Votado (remover)')->assertSee('1 voto');
});
