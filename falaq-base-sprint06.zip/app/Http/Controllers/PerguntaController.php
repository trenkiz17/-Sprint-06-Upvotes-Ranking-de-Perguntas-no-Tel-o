<?php

namespace App\Http\Controllers;

use App\Models\Pergunta;

class PerguntaController extends Controller
{
    /**
     * TICKET #011: alterna (toggle) o voto do usuário autenticado na pergunta.
     * Sem voto -> cria o registro na pivot; com voto -> remove.
     */
    public function votar(Pergunta $pergunta)
    {
        $resultado = $pergunta->votos()->toggle(auth()->id());

        $mensagem = count($resultado['attached']) > 0
            ? 'Voto registrado!'
            : 'Voto removido.';

        return back()->with('sucesso', $mensagem)->with('status', $mensagem);
    }
}
